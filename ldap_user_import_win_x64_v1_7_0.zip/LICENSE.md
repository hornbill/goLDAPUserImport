The Hornbill Community License (HCL)

Copyright (c) 2015 Hornbill Technologies Ltd (https://hornbill.com)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

 * The above copyright notice and this permission notice shall be included in
   all copies or substantial portions of the Software.

 * Where this software is compiled into a stand-alone program the above
   Copyright notice shall be included in the programs published documentation
   and shown in any help or about text provided by the software at runtime
   and shall be visible to the end user of the program.

 * Where this software is used in any way whatsoever to provide a hosted or
   cloud based service, application, web service API or integration, the above
   copyright notice shall be included in the published documentation and
   shown in any help text or about box provided by the software and shall
   be visible to the end user.

 * The ELUA or, in the case of a SaaS or Hosted service, the Terms of Service
   agreement shall include the following statement: -

   Portions of this software Copyright (c) 2015 Hornbill Technologies Ltd
   (https://hornbill.com)

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
